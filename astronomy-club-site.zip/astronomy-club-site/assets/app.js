(function () {
  const qs = (s, r = document) => r.querySelector(s);
  const qsa = (s, r = document) => Array.from(r.querySelectorAll(s));

  /* SETTINGS */
  const SETTINGS = {
    CLUB_NAME: "Astronomy Club",
    CONTACT_EMAIL: "2016raghav.saxena@gmail.com",
    MEETING_CADENCE: "Online every 2 weeks",
    DUES: "Free",
    ICS_FEED: "",            // off by request
    ADMIN_HINT: "common astronomy fan word 😉",
    // sha256("stargazer") base64; change this in production
    ADMIN_SHA256: "cY7nT0uQ3sQgWcm3bh2KH1o6cY7w8pP3r75c2tqf2n0="
  };

  /* THEME */
  const prefersLight = window.matchMedia("(prefers-color-scheme: light)");
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "light" || (!savedTheme && prefersLight.matches)) {
    document.documentElement.classList.add("light");
  }
  qs("#themeToggle").addEventListener("click", () => {
    document.documentElement.classList.toggle("light");
    localStorage.setItem("theme", document.documentElement.classList.contains("light") ? "light" : "dark");
  });

  /* NAV */
  const navToggle = qs("#navToggle");
  const navMenu = qs("#navMenu");
  navToggle.addEventListener("click", () => {
    const open = navMenu.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", String(open));
  });
  qsa(".nav-list a").forEach(a => a.addEventListener("click", () => {
    navMenu.classList.remove("open");
    navToggle.setAttribute("aria-expanded", "false");
  }));

  /* YEAR + email binding */
  qs("#year").textContent = new Date().getFullYear();
  const emailLink = qs("#contactEmail");
  if (emailLink) { emailLink.textContent = SETTINGS.CONTACT_EMAIL; emailLink.href = `mailto:${SETTINGS.CONTACT_EMAIL}`; }

  /* STARFIELD */
  const starCanvas = qs("#starfield");
  const ctx = starCanvas.getContext("2d", { alpha: true });
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let stars = [];
  function resize() {
    starCanvas.width = window.innerWidth;
    starCanvas.height = window.innerHeight;
    const count = Math.floor((starCanvas.width * starCanvas.height) / 12000);
    stars = Array.from({ length: count }, () => ({
      x: Math.random() * starCanvas.width,
      y: Math.random() * starCanvas.height,
      z: Math.random() * 0.8 + 0.2,
      tw: Math.random() * Math.PI * 2
    }));
  }
  window.addEventListener("resize", resize, { passive: true });
  resize();
  function draw() {
    if (reduceMotion) return;
    ctx.clearRect(0, 0, starCanvas.width, starCanvas.height);
    for (const s of stars) {
      s.tw += 0.02;
      const r = s.z * (Math.sin(s.tw) * 0.4 + 0.6);
      ctx.globalAlpha = 0.6 * s.z;
      ctx.beginPath();
      ctx.arc(s.x, s.y, r, 0, Math.PI * 2);
      ctx.fillStyle = "#dbe7ff";
      ctx.fill();
    }
    requestAnimationFrame(draw);
  }
  requestAnimationFrame(draw);

  /* SPACE FACT OF THE WEEK */
  const FACTS = [
    { title: "The sun is not yellow.", blurb: "Sunlight is essentially white; our atmosphere scatters blue light, making the sun look yellow from Earth.", source: "https://svs.gsfc.nasa.gov/12102/" },
    { title: "Most stars you see are in the Milky Way.", blurb: "Every naked-eye star is inside our own galaxy; Andromeda (M31) is a fuzzy patch.", source: "https://chandra.harvard.edu/resources/faq/stars/sources/stars.html" },
    { title: "A day on Venus is longer than its year.", blurb: "Venus rotates ~243 Earth days; year ~225 days.", source: "https://solarsystem.nasa.gov/planets/venus/overview/" },
    { title: "Neutron stars spin incredibly fast.", blurb: "Some pulsars rotate hundreds of times per second.", source: "https://www.nasa.gov/mission_pages/GLAST/science/neutron_stars.html" },
    { title: "Saturn could float in water.", blurb: "Average density is less than water.", source: "https://solarsystem.nasa.gov/planets/saturn/by-the-numbers/" },
    { title: "Telescopes are time machines.", blurb: "Finite light speed means distant views are the past.", source: "https://hubblesite.org/contents/articles/seeing-back-in-time" },
    { title: "Jupiter affects impact risk.", blurb: "Its gravity can deflect or funnel small bodies.", source: "https://science.nasa.gov/jupiter/facts/" }
  ];
  function isoWeekNumber(date = new Date()) {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const day = d.getUTCDay() || 7; d.setUTCDate(d.getUTCDate() + 4 - day);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  }
  (function renderFact() {
    const week = isoWeekNumber();
    const f = FACTS[week % FACTS.length];
    qs("#fact-week-label").textContent = `Week ${week}`;
    qs("#fact-card").innerHTML = `
      <h3 style="margin-bottom:.25rem">${f.title}</h3>
      <p>${f.blurb}</p>
      ${f.source ? `<p class="muted" style="margin-top:.25rem">Source: <a target="_blank" rel="noopener" href="${f.source}">${new URL(f.source).hostname}</a></p>` : ""}
    `;
  })();

  /* EVENTS: load chain → local draft → JSON → stub */
  const eventsList = qs("#eventsList");
  const pastEventsList = qs("#pastEventsList");
  const filterSelect = qs("#eventFilter");
  const exportBtn = qs("#exportIcs");
  let events = [];

  const DRAFT_KEY = "events_draft_v1";

  async function loadEvents() {
    const draft = localStorage.getItem(DRAFT_KEY);
    if (draft) {
      try { events = JSON.parse(draft); renderEvents(filterSelect.value); return; } catch {}
    }
    try {
      const res = await fetch("data/events.json", { cache: "no-store" });
      if (res.ok) {
        events = await res.json();
      } else { events = stubEvents(); }
    } catch { events = stubEvents(); }
    renderEvents(filterSelect.value);
  }

  function stubEvents() {
    const a = nextSaturdayAt(19, 0);
    const b = new Date(a.getTime() + 14 * 864e5);
    return [
      { title: "Online Star Party", date: a.toISOString(), location: "Virtual", tags: ["star-party", "online"], blurb: "Live sky tour + Q&A. Zoom link emailed to subscribers.", link: "#" },
      { title: "Astrophotography Basics (Online)", date: b.toISOString(), location: "Virtual", tags: ["workshop", "online"], blurb: "Stacking, calibration frames, and simple processing workflow.", link: "#" }
    ];
  }

  function nextSaturdayAt(h = 19, m = 0) {
    const now = new Date();
    const d = new Date(now);
    const day = d.getDay(); const delta = (6 - day + 7) % 7 || 7;
    d.setDate(d.getDate() + delta); d.setHours(h, m, 0, 0);
    return d;
  }

  function dateFmt(iso) {
    const d = new Date(iso);
    return d.toLocaleString([], { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });
  }

  function toGCalDt(dt) {
    const d = new Date(dt);
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}00Z`;
  }

  function gcalAddLink(evt) {
    const start = toGCalDt(evt.date);
    const end = toGCalDt(evt.end || new Date(new Date(evt.date).getTime() + 60 * 60 * 1000));
    const params = new URLSearchParams({
      action: "TEMPLATE", text: evt.title, dates: `${start}/${end}`,
      details: (evt.blurb || "") + (evt.link && evt.link !== "#" ? `\n${evt.link}` : ""), location: evt.location || ""
    });
    return `https://calendar.google.com/calendar/render?${params.toString()}`;
  }

  function renderEvents(tag = "all") {
    const now = new Date();
    const filtered = events.filter(e => tag === "all" || (e.tags || []).includes(tag));
    const upcoming = filtered.filter(e => new Date(e.date) >= now).sort((a, b) => new Date(a.date) - new Date(b.date));
    const past = filtered.filter(e => new Date(e.date) < now).sort((a, b) => new Date(b.date) - new Date(a.date));

    eventsList.innerHTML = upcoming.length ? upcoming.map(card).join("") :
      `<p class="muted">No upcoming ${tag === "all" ? "" : tag.replace("-", " ")} events. Check back soon.</p>`;
    pastEventsList.innerHTML = past.slice(0, 8).map(card).join("");

    exportBtn.disabled = upcoming.length === 0;
    exportBtn.setAttribute("aria-disabled", String(upcoming.length === 0));
    exportBtn.onclick = () => exportICS(upcoming);
  }

  function card(e) {
    const tagChips = (e.tags || []).map(t => `<span class="chip">${t.replace("-", " ")}</span>`).join(" ");
    const addUrl = gcalAddLink(e);
    return `
      <article class="card">
        <h3>${e.title}</h3>
        <p class="muted">${dateFmt(e.date)} • ${e.location || "Online"}</p>
        <p>${e.blurb || ""}</p>
        <div class="chips">${tagChips}</div>
        <div style="display:flex; gap:.5rem; flex-wrap:wrap">
          <a class="btn btn--small" href="${e.link || "#"}">Details</a>
          <a class="btn btn--small" target="_blank" rel="noopener" href="${addUrl}">Add to Google Calendar</a>
        </div>
      </article>
    `;
  }

  /* ICS export */
  function icsEscape(s) { return String(s).replace(/([,;])/g, "\\$1").replace(/\n/g, "\\n"); }
  function formatDt(dt) { const d = new Date(dt), pad = (n) => String(n).padStart(2, "0"); return `${d.getUTCFullYear()}${pad(d.getUTCMonth()+1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}00Z`; }
  function exportICS(upcoming) {
    const lines = ["BEGIN:VCALENDAR","VERSION:2.0",`PRODID:-//${SETTINGS.CLUB_NAME}//Events//EN`,"CALSCALE:GREGORIAN","METHOD:PUBLISH"];
    for (const e of upcoming) {
      const uid = `${Date.now()}-${Math.random().toString(36).slice(2)}@${location.host || "astronomy.club"}`;
      lines.push("BEGIN:VEVENT",`UID:${uid}`,`DTSTAMP:${formatDt(new Date())}`,`DTSTART:${formatDt(e.date)}`,e.end ? `DTEND:${formatDt(e.end)}` : undefined,`SUMMARY:${icsEscape(e.title)}`,`LOCATION:${icsEscape(e.location || "")}`,`DESCRIPTION:${icsEscape(e.blurb || "")}${e.link ? "\\n" + icsEscape(e.link) : ""}`,"END:VEVENT").filter(Boolean);
    }
    lines.push("END:VCALENDAR");
    const blob = new Blob([lines.join("\r\n")], { type: "text/calendar;charset=utf-8" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${SETTINGS.CLUB_NAME.toLowerCase().replace(/\s+/g,"-")}.ics`;
    document.body.appendChild(a); a.click(); URL.revokeObjectURL(a.href); a.remove();
  }

  /* GALLERY */
  const gallery = [
    { src: "https://science.nasa.gov/wp-content/uploads/2023/05/stsci-01gfn9wt0p8a8m3b9p4d7t3r8v.png", alt: "JWST 'Cosmic Cliffs' in the Carina Nebula", cap: "JWST Cosmic Cliffs — NASA/ESA/CSA", href: "https://science.nasa.gov/missions/webb/nasas-webb-reveals-cosmic-cliffs-glittering-landscape-of-star-birth/" },
    { src: "https://upload.wikimedia.org/wikipedia/commons/1/1f/Pillars_of_creation_2014_HST_WFC3-UVIS_full-res_denoised.jpg", alt: "Hubble Pillars of Creation visible light", cap: "Pillars of Creation — Hubble", href: "https://esahubble.org/images/heic1501a/" },
    { src: "https://www.eso.org/public/archives/images/large/eso1242a.jpg", alt: "Milky Way center wide-field VISTA mosaic", cap: "Milky Way Centre — ESO/VISTA", href: "https://www.eso.org/public/images/eso1242a/" },
    { src: "https://images-assets.nasa.gov/image/201508130002HQ/201508130002HQ~orig.jpg", alt: "Perseid meteor over Spruce Knob, West Virginia", cap: "Perseids — NASA", href: "https://www.nasa.gov/image-article/perseids-meteor-shower/" }
  ];
  const galleryGrid = qs("#galleryGrid");
  if (galleryGrid) galleryGrid.innerHTML = gallery.map(g => `
    <figure tabindex="0" class="card gallery-item">
      <a href="${g.href}" target="_blank" rel="noopener"><img src="${g.src}" alt="${g.alt}" loading="lazy"></a>
      <figcaption class="muted">${g.cap}</figcaption>
    </figure>
  `).join("");

  /* LIGHTBOX */
  const lightbox = qs("#lightbox");
  if (lightbox) {
    const lbImg = qs(".lightbox-img", lightbox);
    const lbCap = qs(".lightbox-caption", lightbox);
    const lbClose = qs(".lightbox-close", lightbox);
    const lbPrev = qs(".prev", lightbox);
    const lbNext = qs(".next", lightbox);
    let lbIndex = 0;
    qsa(".gallery-item").forEach((fig, i) => {
      fig.addEventListener("click", (e) => { if (e.target.tagName === "IMG") { e.preventDefault(); openLB(i); } });
      fig.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openLB(i); } });
    });
    function openLB(i) { lbIndex = i; const g = gallery[lbIndex]; lbImg.src = g.src; lbImg.alt = g.alt; lbCap.textContent = g.cap; lightbox.classList.add("open"); lightbox.setAttribute("aria-hidden","false"); lbClose.focus(); }
    function closeLB() { lightbox.classList.remove("open"); lightbox.setAttribute("aria-hidden","true"); }
    function navLB(dir) { lbIndex = (lbIndex + dir + gallery.length) % gallery.length; openLB(lbIndex); }
    lbClose.addEventListener("click", closeLB);
    lbPrev.addEventListener("click", () => navLB(-1));
    lbNext.addEventListener("click", () => navLB(1));
    window.addEventListener("keydown", (e) => { if (!lightbox.classList.contains("open")) return; if (e.key === "Escape") closeLB(); if (e.key === "ArrowLeft") navLB(-1); if (e.key === "ArrowRight") navLB(1); });
  }

  /* FORMS */
  function validate(form) {
    const msg = qs(".form-msg", form);
    if (!form.checkValidity()) { msg.textContent = "Please fill all required fields correctly."; msg.style.color = "#ffb4b4"; return false; }
    msg.textContent = ""; return true;
  }
  const nf = qs("#newsletterForm");
  if (nf) nf.addEventListener("submit", (e) => {
    e.preventDefault(); const form = e.currentTarget; if (!validate(form)) return;
    const data = Object.fromEntries(new FormData(form));
    const subs = JSON.parse(localStorage.getItem("newsletter") || "[]");
    subs.push({ ...data, t: Date.now() }); localStorage.setItem("newsletter", JSON.stringify(subs));
    form.reset(); const msg = qs(".form-msg", form); msg.textContent = "Thanks! You're on the list."; msg.style.color = "var(--accent)";
  });
  const cf = qs("#contactForm");
  if (cf) cf.addEventListener("submit", (e) => {
    e.preventDefault(); const form = e.currentTarget; if (!validate(form)) return;
    const data = Object.fromEntries(new FormData(form));
    const mail = `mailto:${SETTINGS.CONTACT_EMAIL}?subject=${encodeURIComponent("Contact from " + data.name)}&body=${encodeURIComponent(data.message + "\n\nReply to: " + data.email)}`;
    window.location.href = mail; form.reset(); const msg = qs(".form-msg", form); msg.textContent = "Opening your email client…"; msg.style.color = "var(--accent)";
  });

  /* ===== Admin gate (client-only) ===== */
  async function sha256Base64(s) {
    const enc = new TextEncoder().encode(s);
    const buf = await crypto.subtle.digest("SHA-256", enc);
    const bytes = new Uint8Array(buf);
    let bin = ""; for (let i = 0; i < bytes.byteLength; i++) bin += String.fromCharCode(bytes[i]);
    return btoa(bin);
  }
  async function requireAdmin() {
    if (sessionStorage.getItem("admin_ok") === "1") return true;
    const pass = prompt(`Enter admin passphrase (${SETTINGS.ADMIN_HINT})`);
    if (!pass) return false;
    const h = await sha256Base64(pass);
    if (h === SETTINGS.ADMIN_SHA256) { sessionStorage.setItem("admin_ok","1"); return true; }
    alert("Incorrect passphrase."); return false;
  }

  /* ===== EVENTS EDITOR (local only) ===== */
  const openEditorBtn = qs("#openEditor");
  const modal = qs("#editorModal");
  const closeEditorBtn = qs("#closeEditor");
  const rowsTbody = qs("#editorRows");
  const form = qs("#eventForm");
  const formMsg = qs("#formMsg");
  const importFile = qs("#importFile");
  const downloadBtn = qs("#downloadJson");
  const clearDraftBtn = qs("#clearDraft");
  let editIndex = null;

  function refreshTable() {
    rowsTbody.innerHTML = events.map((e, i) => `
      <tr>
        <td>${escapeHtml(e.title || "")}</td>
        <td>${dateFmt(e.date || "")}</td>
        <td>${escapeHtml(e.location || "")}</td>
        <td>${(e.tags || []).join(", ")}</td>
        <td>
          <div class="row-actions">
            <button type="button" data-act="edit" data-i="${i}" class="btn btn--small">Edit</button>
            <button type="button" data-act="del" data-i="${i}" class="btn btn--small">Delete</button>
          </div>
        </td>
      </tr>
    `).join("");
  }

  function openEditor() { modal.classList.add("open"); modal.setAttribute("aria-hidden","false"); refreshTable(); }
  function closeEditor() { modal.classList.remove("open"); modal.setAttribute("aria-hidden","true"); form.reset(); editIndex = null; formMsg.textContent = ""; }

  function saveDraft() {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(events));
    formMsg.textContent = "Draft saved locally.";
    renderEvents(filterSelect.value);
  }

  function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  if (openEditorBtn) openEditorBtn.addEventListener("click", async () => {
    if (await requireAdmin()) openEditor();
  });
  if (closeEditorBtn) closeEditorBtn.addEventListener("click", closeEditor);
  if (modal) modal.addEventListener("click", (e) => { if (e.target === modal) closeEditor(); });

  if (rowsTbody) rowsTbody.addEventListener("click", (e) => {
    const btn = e.target.closest("button"); if (!btn) return;
    const i = Number(btn.dataset.i);
    if (btn.dataset.act === "edit") {
      editIndex = i;
      const ev = events[i];
      form.title.value = ev.title || "";
      form.date.value = ev.date ? new Date(ev.date).toISOString().slice(0,16) : "";
      form.location.value = ev.location || "";
      form.tags.value = (ev.tags || []).join(", ");
      form.blurb.value = ev.blurb || "";
      form.link.value = ev.link || "";
      formMsg.textContent = "Editing row " + (i + 1);
    } else if (btn.dataset.act === "del") {
      events.splice(i, 1); saveDraft(); refreshTable();
    }
  });

  if (form) form.addEventListener("submit", (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form));
    if (!data.title || !data.date) { formMsg.textContent = "Title and Date are required."; return; }
    const evt = {
      title: data.title.trim(),
      date: new Date(data.date).toISOString(),
      location: data.location?.trim() || "Virtual",
      tags: data.tags ? data.tags.split(",").map(t => t.trim()).filter(Boolean) : [],
      blurb: data.blurb?.trim() || "",
      link: data.link?.trim() || "#"
    };
    if (editIndex === null) events.push(evt); else events[editIndex] = evt;
    editIndex = null; form.reset(); saveDraft(); refreshTable();
  });

  if (importFile) importFile.addEventListener("change", async () => {
    const f = importFile.files?.[0]; if (!f) return;
    try {
      const txt = await f.text();
      const arr = JSON.parse(txt);
      if (!Array.isArray(arr)) throw new Error("Not an array");
      events = arr; saveDraft(); refreshTable();
    } catch {
      alert("Invalid JSON file. Expecting an array of events.");
    } finally { importFile.value = ""; }
  });

  if (downloadBtn) downloadBtn.addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(events, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "events.json";
    document.body.appendChild(a); a.click(); URL.revokeObjectURL(a.href); a.remove();
  });

  if (clearDraftBtn) clearDraftBtn.addEventListener("click", () => {
    localStorage.removeItem(DRAFT_KEY); formMsg.textContent = "Draft cleared (reloading from file next refresh).";
  });

  filterSelect.addEventListener("change", () => renderEvents(filterSelect.value));
  loadEvents();
})();